const config = {
        botName: 'ToinBOT',
        ownerName: 'Toin',
        youtube: 'YOUTUBE_LINK',
        instagram: 'INSTAGRAM_LINK',
}
